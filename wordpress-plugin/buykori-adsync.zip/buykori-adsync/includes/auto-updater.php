<?php

if (!defined('ABSPATH')) {
    exit;
}

function buykorigw_clear_update_cache()
{
    $settings = buykorigw_get_settings();
    $cache_key = 'buykorigw_update_info_' . BUYKORIGW_VERSION . '_' . md5($settings['api_key'] ?? '');

    delete_transient($cache_key);
    delete_site_transient('update_plugins');

    if (function_exists('wp_clean_plugins_cache')) {
        wp_clean_plugins_cache(true);
    }
}

class BUYKORIGW_Auto_Updater
{

    private $plugin_slug;
    private $plugin_file;
    private $current_version;
    private $update_url;

    public function __construct()
    {
        $this->plugin_slug = 'buykori-adsync';
        $this->plugin_file = 'buykori-adsync/buykori-adsync.php';
        $this->current_version = BUYKORIGW_VERSION;

        $settings = buykorigw_get_settings();
        $gateway = rtrim($settings['gateway_url'], '/');
        $base_url = preg_replace('#/api/v1/?$#', '', $gateway);
        $this->update_url = $base_url . '/api/v1/plugin/update-check';

        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_for_update'));
        add_filter('plugins_api', array($this, 'plugin_info'), 20, 3);
        add_filter('upgrader_pre_download', array($this, 'verify_downloaded_package'), 10, 3);
    }

    public function check_for_update($transient)
    {
        if (empty($transient->checked)) {
            return $transient;
        }

        $remote = $this->get_remote_info();

        if ($remote && version_compare($this->current_version, $remote->version, '<')) {
            $plugin_data = new stdClass();
            $plugin_data->slug = $this->plugin_slug;
            $plugin_data->plugin = $this->plugin_file;
            $plugin_data->new_version = $remote->version;
            $plugin_data->url = $remote->homepage ?? '';
            $plugin_data->package = $remote->download_url ?? '';
            $plugin_data->tested = $remote->tested ?? '6.7';
            $plugin_data->requires = $remote->requires ?? '5.8';
            $plugin_data->requires_php = $remote->requires_php ?? '7.4';

            $transient->response[$this->plugin_file] = $plugin_data;
        }

        return $transient;
    }

    public function plugin_info($result, $action, $args)
    {
        if ($action !== 'plugin_information' || $args->slug !== $this->plugin_slug) {
            return $result;
        }

        $remote = $this->get_remote_info();

        if (!$remote) {
            return $result;
        }

        $info = new stdClass();
        $info->name = 'Buykori AdSync — Server-Side Tracking';
        $info->slug = $this->plugin_slug;
        $info->version = $remote->version;
        $info->author = '<a href="' . esc_url($remote->homepage ?? '') . '">Buykori AdSync</a>';
        $info->homepage = $remote->homepage ?? '';
        $info->download_link = $remote->download_url ?? '';
        $info->tested = $remote->tested ?? '6.7';
        $info->requires = $remote->requires ?? '5.8';
        $info->requires_php = $remote->requires_php ?? '7.4';
        $info->last_updated = $remote->last_updated ?? '';
        $info->sections = array(
            'description' => $remote->description ?? 'Server-Side Facebook CAPI tracking for WooCommerce.',
            'changelog' => $remote->changelog ?? '<p>Bug fixes and improvements.</p>',
        );

        if (!empty($remote->banner)) {
            $info->banners = array('high' => $remote->banner);
        }

        return $info;
    }

    private function get_remote_info()
    {
        $settings = buykorigw_get_settings();
        $cache_key = 'buykorigw_update_info_' . BUYKORIGW_VERSION . '_' . md5($settings['api_key'] ?? '');
        $cached = get_transient($cache_key);

        if ($cached !== false) {
            return $cached;
        }

        $request_url = add_query_arg(array(
            'installed_version' => $this->current_version,
            'cache_bust' => time(),
        ), $this->update_url);

        $response = wp_remote_get($request_url, array(
            'timeout' => 10,
            'sslverify' => true,
            'headers' => array(
                'X-API-Key' => $settings['api_key'] ?? '',
                'X-Plugin-Version' => $this->current_version,
            ),
        ));

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return false;
        }

        $body = json_decode(wp_remote_retrieve_body($response));

        if (empty($body) || empty($body->version)) {
            return false;
        }

        if (!$this->verify_remote_info($body, $settings['api_key'] ?? '')) {
            return false;
        }

        set_transient($cache_key, $body, 12 * HOUR_IN_SECONDS);

        return $body;
    }

    private function verify_remote_info($remote, $api_key)
    {
        if (empty($remote->download_url) || empty($remote->package_sha256) || empty($remote->signature) || empty($api_key)) {
            return false;
        }

        if (!$this->package_url_allowed($remote->download_url)) {
            return false;
        }

        if (!preg_match('/^[a-f0-9]{64}$/', $remote->package_sha256)) {
            return false;
        }

        $payload = $remote->version . '|' . $remote->download_url . '|' . $remote->package_sha256;
        $expected = hash_hmac('sha256', $payload, $api_key);
        return hash_equals($expected, $remote->signature);
    }

    private function package_url_allowed($download_url)
    {
        $update_host = strtolower(wp_parse_url($this->update_url, PHP_URL_HOST));
        $package_host = strtolower(wp_parse_url($download_url, PHP_URL_HOST));
        $scheme = wp_parse_url($download_url, PHP_URL_SCHEME);

        if ($scheme !== 'https' || !$update_host || !$package_host) {
            return false;
        }

        if ($update_host === $package_host) {
            return true;
        }

        $allowed_hosts = array(
            'buykori.app',
            'www.buykori.app',
            'api.buykori.app',
        );
        if (in_array($package_host, $allowed_hosts, true)) {
            return true;
        }

        if (preg_match('/^([a-z0-9-]+\.)*(buykori\.app)$/', $package_host)) {
            return true;
        }

        return false;
    }

    public function verify_downloaded_package($reply, $package, $upgrader)
    {
        $remote = $this->get_remote_info();
        if (!$remote || empty($remote->download_url) || $package !== $remote->download_url) {
            return $reply;
        }

        $downloaded = download_url($package);
        if (is_wp_error($downloaded)) {
            return $downloaded;
        }

        $actual_hash = hash_file('sha256', $downloaded);
        if (!hash_equals($remote->package_sha256, $actual_hash)) {
            @unlink($downloaded);
            return new WP_Error('buykorigw_update_hash_mismatch', 'Buykori AdSync update package verification failed.');
        }

        return $downloaded;
    }
}

new BUYKORIGW_Auto_Updater();
